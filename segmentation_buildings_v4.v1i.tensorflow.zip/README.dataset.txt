# segmentation_buildings_v4 > 2023-05-31 5:24pm
https://universe.roboflow.com/onesystem/segmentation_buildings_v4

Provided by a Roboflow user
License: CC BY 4.0

